plugins {
    kotlin("jvm") version "1.9.10"
    id("application")
}

group = "com.elcasador"
version = "1.0.0"

application {
    mainClass.set("com.elcasador.ApplicationKt")
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("io.ktor:ktor-server-core-jvm:2.3.4")
    implementation("io.ktor:ktor-server-netty-jvm:2.3.4")
    implementation("io.ktor:ktor-server-websockets-jvm:2.3.4")
    implementation("io.ktor:ktor-server-content-negotiation-jvm:2.3.4")
    implementation("io.ktor:ktor-serialization-kotlinx-json-jvm:2.3.4")
    implementation("ch.qos.logback:logback-classic:1.4.11")
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    implementation("com.github.ben-manes.caffeine:caffeine:3.1.8")
    testImplementation(kotlin("test"))
}

kotlin {
    jvmToolchain(17)
}
