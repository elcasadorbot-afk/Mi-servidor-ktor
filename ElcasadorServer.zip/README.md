# ElcasadorServer
Servidor Ktor (Kotlin) con REST + WebSocket preparado para desplegar en Render.

## Deploy rápido
- Push al repo en GitHub
- Conectar repo a Render (Web Service)
- Build command: `./gradlew shadowJar`
- Start command: `java -jar build/libs/elcasadorserver-1.0.0-all.jar`

## Env vars
- PORT (default 8080)
- ADMIN_TOKEN
- EXTERNAL_API (default https://ipwhois.app/json/)
- CACHE_TTL_SECONDS (default 45)
- RATE_PER_MIN (default 120)
