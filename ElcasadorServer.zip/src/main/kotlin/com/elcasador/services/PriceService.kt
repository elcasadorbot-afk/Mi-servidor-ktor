package com.elcasador.services

import kotlin.math.*

class PriceService(private val baseFare: Double = 0.5, private val perKm: Double = 0.35) {
    fun haversineDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat/2).pow(2.0) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon/2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1-a))
        return R * c
    }

    fun calculatePriceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val km = haversineDistanceKm(lat1, lon1, lat2, lon2)
        return (baseFare + perKm * km).coerceAtLeast(1.0)
    }
}
