package com.elcasador.services

import com.elcasador.config.AppConfig

class AuthService(private val config: AppConfig) {
    fun checkToken(token: String?): Boolean {
        if (token == null) return false
        return token == config.adminToken
    }
}
