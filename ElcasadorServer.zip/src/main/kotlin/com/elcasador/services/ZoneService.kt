package com.elcasador.services

import java.util.concurrent.ConcurrentHashMap

class ZoneService {
    private val zones = ConcurrentHashMap<String, Zone>()

    data class Zone(val id: String, val name: String, val polygon: List<Pair<Double,Double>>)

    fun addZone(zone: Zone) {
        zones[zone.id] = zone
    }

    fun removeZone(id: String) {
        zones.remove(id)
    }

    fun listZones(): List<Zone> = zones.values.toList()

    fun isPointInZone(lat: Double, lon: Double): Boolean {
        for (z in zones.values) {
            if (pointInPolygon(lat, lon, z.polygon)) return true
        }
        return false
    }

    private fun pointInPolygon(lat: Double, lon: Double, poly: List<Pair<Double,Double>>): Boolean {
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val xi = poly[i].first
            val yi = poly[i].second
            val xj = poly[j].first
            val yj = poly[j].second

            val intersect = ((yi > lon) != (yj > lon)) &&
                    (lat < (xj - xi) * (lon - yi) / (yj - yi + 0.0) + xi)
            if (intersect) inside = !inside
            j = i
        }
        return inside
    }
}
