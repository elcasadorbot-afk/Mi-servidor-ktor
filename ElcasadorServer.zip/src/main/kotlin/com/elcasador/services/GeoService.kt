package com.elcasador.services

import com.elcasador.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import com.github.benmanes.caffeine.cache.Caffeine
import java.util.concurrent.TimeUnit

@Serializable
data class GeoResponse(
    val ip: String? = null,
    val country: String? = null,
    val country_code: String? = null,
    val city: String? = null,
    val region: String? = null,
    val currency: String? = null,
    val timezone: String? = null,
    val lat: Double? = null,
    val lon: Double? = null
)

class GeoService(private val config: AppConfig) {
    private val client = OkHttpClient()
    private val cache = Caffeine.newBuilder()
        .expireAfterWrite(config.cacheTtlMillis, TimeUnit.MILLISECONDS)
        .maximumSize(10_000)
        .build<String, GeoResponse>()

    suspend fun getGeoForIp(ip: String?): GeoResponse = withContext(Dispatchers.IO) {
        val key = ip ?: "self"
        val cached = cache.getIfPresent(key)
        if (cached != null) return@withContext cached

        val url = if (ip == null) config.externalApi else "${config.externalApi}${ip}/json/"
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string() ?: "{}"
            val parsed = Json.decodeFromString(GeoResponse.serializer(), body)
            cache.put(key, parsed)
            return@withContext parsed
        }
    }
}
